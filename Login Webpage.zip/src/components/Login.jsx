import React, { useState } from "react";
import "../styles/login.css";

// writing logic for the login page;
// using useState hook to store the username and password
export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  function handleSubmit(e) {
    // e.preventDefault(); prevent the default form submission, which is to reload the page
    e.preventDefault();
    if (!username || !password) {
      // if username or password is empty, display an alert message
      alert("Please fill all fields");
    } else {
      alert("Login Successful");
    }
  }
  return (
    <div className="login">
      <h1>Login</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <button onClick={handleSubmit} type="submit">
          Login
        </button>
        <br />

        <a href="#">Forgot Password?</a>
      </form>
    </div>
  );
}
