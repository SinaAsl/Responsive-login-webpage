import { React } from 'react'
import Login from './components/login'
import './App.css'

function App() {

  
  return (
    <>
<Login />
    </>
  )
}

export default App
